
{{/* Full name of the application */}}
{{- define "memgraph.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end -}}
{{- end -}}



{{/*
Fully qualified name for the mg-exporter resources.
Prefixing with the release-scoped fullname allows multiple releases of this
chart to coexist in the same namespace without name collisions.
*/}}
{{- define "memgraph.exporter.fullname" -}}
{{- printf "%s-mg-exporter" (include "memgraph.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/* Define the chart version and app version */}}
{{- define "memgraph.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end -}}


{{/* Define the name of the application */}}
{{- define "memgraph.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end -}}


{{/*
Validate the external access configuration. Fails rendering when mutually
exclusive options are enabled. Included from the core StatefulSet templates so
it triggers at template time (helm template / lint), not only when the
cluster-setup hook runs.
*/}}
{{- define "memgraph.validateExternalAccess" -}}
{{- if .Values.externalAccessConfig.gateway.enabled -}}
{{- $dataHasServiceType := ne (.Values.externalAccessConfig.dataInstance.serviceType | default "") "" -}}
{{- $coordHasServiceType := ne (.Values.externalAccessConfig.coordinator.serviceType | default "") "" -}}
{{- if and $dataHasServiceType $coordHasServiceType -}}
{{- fail "externalAccessConfig.gateway.enabled requires at least one tier without a serviceType: a tier with dataInstance/coordinator.serviceType set is excluded from the Gateway, so with both set the Gateway would apply to nothing. Unset one serviceType or disable the gateway." -}}
{{- end -}}
{{- end -}}
{{- end -}}


{{/*
Annotations for the shared ingress-nginx controller Service. Only tiers whose
serviceType is "IngressNginx" contribute — a CommonLoadBalancer/LoadBalancer/
NodePort tier gets its own service elsewhere and must not leak its external-dns
hostname onto the ingress controller. When both tiers are IngressNginx the maps
are merged and the coordinator value wins on a key collision (last-write-wins).
Rendered as YAML — callers pipe through `fromYaml` to get a dict back.
*/}}
{{- define "memgraph.externalAccessAnnotations" -}}
{{- $out := dict -}}
{{- if eq .Values.externalAccessConfig.dataInstance.serviceType "IngressNginx" -}}
{{- $out = mergeOverwrite $out (.Values.externalAccessConfig.dataInstance.annotations | default dict) -}}
{{- end -}}
{{- if eq .Values.externalAccessConfig.coordinator.serviceType "IngressNginx" -}}
{{- $out = mergeOverwrite $out (.Values.externalAccessConfig.coordinator.annotations | default dict) -}}
{{- end -}}
{{- $out | toYaml -}}
{{- end -}}


{{/* Common labels */}}
{{- define "memgraph.labels" -}}
app.kubernetes.io/name: {{ include "memgraph.name" . }}
helm.sh/chart: {{ include "memgraph.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}


{{/*
Create the name of the service account to use
*/}}
{{- define "memgraph.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "memgraph.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "container.data.readinessProbe" -}}
{{- $p := .Values.container.data.readinessProbe -}}
readinessProbe:
  tcpSocket:
    port: {{ .Values.ports.boltPort }}
  failureThreshold: {{ $p.failureThreshold }}
  timeoutSeconds: {{ $p.timeoutSeconds }}
  periodSeconds: {{ $p.periodSeconds }}
{{- end }}


{{- define "container.data.livenessProbe" -}}
{{- $p := .Values.container.data.livenessProbe -}}
livenessProbe:
  tcpSocket:
    port: {{ .Values.ports.boltPort }}
  failureThreshold: {{ $p.failureThreshold }}
  timeoutSeconds: {{ $p.timeoutSeconds }}
  periodSeconds: {{ $p.periodSeconds }}
{{- end }}


{{- define "container.data.startupProbe" -}}
{{- $p := .Values.container.data.startupProbe -}}
startupProbe:
  tcpSocket:
    port: {{ .Values.ports.boltPort }}
  failureThreshold: {{ $p.failureThreshold }}
  timeoutSeconds: {{ $p.timeoutSeconds }}
  periodSeconds: {{ $p.periodSeconds }}
{{- end }}



{{- define "container.coordinators.readinessProbe" -}}
{{- $p := .Values.container.coordinators.readinessProbe -}}
readinessProbe:
  tcpSocket:
    port: {{ .Values.ports.coordinatorPort }}
  failureThreshold: {{ $p.failureThreshold }}
  timeoutSeconds: {{ $p.timeoutSeconds }}
  periodSeconds: {{ $p.periodSeconds }}
{{- end }}


{{- define "container.coordinators.livenessProbe" -}}
{{- $p := .Values.container.coordinators.livenessProbe -}}
livenessProbe:
  tcpSocket:
    port: {{ .Values.ports.coordinatorPort }}
  failureThreshold: {{ $p.failureThreshold }}
  timeoutSeconds: {{ $p.timeoutSeconds }}
  periodSeconds: {{ $p.periodSeconds }}
{{- end }}


{{- define "memgraph.commonLoggingArgs" -}}
{{- $logging := .logging -}}
{{- if not $logging.log_level -}}{{- fail (printf "%s.log_level must not be empty" .path) -}}{{- end -}}
{{- if not (kindIs "bool" $logging.also_log_to_stderr) -}}{{- fail (printf "%s.also_log_to_stderr must be a boolean (true or false)" .path) -}}{{- end -}}
- "--log-level={{ $logging.log_level }}"
{{- if $logging.also_log_to_stderr }}
- "--also-log-to-stderr"
{{- end }}
- "--log-file={{ $logging.log_file }}"
- "--log-retention-days={{ $logging.log_retention_days }}"
{{- end }}


{{- define "container.coordinators.startupProbe" -}}
{{- $p := .Values.container.coordinators.startupProbe -}}
startupProbe:
  tcpSocket:
    port: {{ .Values.ports.coordinatorPort }}
  failureThreshold: {{ $p.failureThreshold }}
  timeoutSeconds: {{ $p.timeoutSeconds }}
  periodSeconds: {{ $p.periodSeconds }}
{{- end }}


{{/*
Core dump uploader sidecar container.
Expects a dict with keys: volumeName, mountPath, values (coreDumpUploader values block).
*/}}
{{- define "memgraph.coreDumpUploader" -}}
- name: core-dump-uploader
  image: "{{ .values.image.repository }}:{{ .values.image.tag }}"
  imagePullPolicy: {{ .values.image.pullPolicy }}
  command: ["/bin/sh", "-c"]
  args:
    - |
      WATCH_DIR="$WATCH_DIR"
      UPLOADED="/tmp/uploaded_files"
      touch "$UPLOADED"
      echo "Core dump uploader started. Watching $WATCH_DIR every ${POLL_INTERVAL}s."
      while true; do
        for f in "$WATCH_DIR"/core.*; do
          [ -e "$f" ] || continue
          fname=$(basename "$f")
          if grep -qxF "$fname" "$UPLOADED"; then
            continue
          fi
          echo "New core dump detected: $fname. Waiting 5s for write to complete..."
          sleep 5
          echo "Uploading $fname to s3://${S3_BUCKET}/${S3_PREFIX}/${HOSTNAME}/${fname}"
          aws s3 cp "$f" "s3://${S3_BUCKET}/${S3_PREFIX}/${HOSTNAME}/${fname}" --region "$AWS_REGION"
          if [ $? -eq 0 ]; then
            echo "$fname" >> "$UPLOADED"
            echo "Upload complete: $fname"
          else
            echo "Upload failed: $fname. Will retry next cycle."
          fi
        done
        sleep "$POLL_INTERVAL"
      done
  env:
    - name: WATCH_DIR
      value: {{ .mountPath | quote }}
    - name: S3_BUCKET
      value: {{ .values.s3BucketName | quote }}
    - name: S3_PREFIX
      value: {{ .values.s3Prefix | quote }}
    - name: AWS_REGION
      value: {{ .values.awsRegion | quote }}
    - name: POLL_INTERVAL
      value: {{ .values.pollIntervalSeconds | quote }}
    - name: AWS_ACCESS_KEY_ID
      valueFrom:
        secretKeyRef:
          name: {{ .values.secretName }}
          key: {{ .values.accessKeySecretKey }}
    - name: AWS_SECRET_ACCESS_KEY
      valueFrom:
        secretKeyRef:
          name: {{ .values.secretName }}
          key: {{ .values.secretAccessKeySecretKey }}
  volumeMounts:
    - name: {{ .volumeName }}
      mountPath: {{ .mountPath }}
      readOnly: true
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop: ["ALL"]
    readOnlyRootFilesystem: false
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
  {{- with .values.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end }}

{{/*
Vector sidecar for log export (VictoriaLogs/Loki).
Expects dict with: ctx (root context), role ("data" or "coordinator").
*/}}
{{- define "memgraph.vectorSidecar" -}}
{{- $v := .ctx.Values.vectorRemote }}
- name: memgraph-vector
  image: "{{ $v.image.repository }}:{{ $v.image.tag }}"
  imagePullPolicy: {{ $v.image.pullPolicy }}
  command: ["/bin/sh", "-ec"]
  args:
    - |
      # Wait for Memgraph to open the log websocket so Vector does not exit with connection errors.
      echo "Waiting for Memgraph monitoring port {{ $v.websocketPort }}..."
      max_wait_seconds=120
      elapsed=0
      until bash -c "exec 3<>/dev/tcp/127.0.0.1/{{ $v.websocketPort }}" >/dev/null 2>&1; do
        if [ "$elapsed" -ge "$max_wait_seconds" ]; then
          echo "Timed out waiting for Memgraph monitoring port {{ $v.websocketPort }} after ${max_wait_seconds}s" >&2
          exit 1
        fi
        sleep 2
        elapsed=$((elapsed + 2))
      done
      cat > /tmp/vector.yaml << VECEOF
      data_dir: /tmp/vector-data

      sources:
        memgraph_logs:
          type: websocket
          uri: "ws://127.0.0.1:{{ $v.websocketPort }}"

      transforms:
        enrich:
          type: remap
          inputs: [memgraph_logs]
          source: |
            normalized_level = ""
            if exists(.message) && is_string(.message) {
              parsed, err = parse_json(.message)
              if err == null && is_object(parsed) {
                . = merge!(., parsed)
              }
            }
            if exists(.level) {
              normalized_level = downcase(to_string!(.level))
            } else if exists(.severity) {
              normalized_level = downcase(to_string!(.severity))
            }
            if normalized_level == "warning" {
              normalized_level = "warn"
            } else if normalized_level == "critical" {
              normalized_level = "fatal"
            }
            if normalized_level == "" {
              normalized_level = "unknown"
            }
            .level = normalized_level
            if !exists(._msg) {
              if exists(.message) {
                ._msg = to_string!(.message)
              } else if exists(.msg) {
                ._msg = to_string!(.msg)
              } else if exists(.log) {
                ._msg = to_string!(.log)
              } else {
                ._msg = encode_json(.)
              }
            }
            .message = ._msg
            .app = "memgraph"
            .job = "memgraph"
            .role = get_env_var!("ROLE")
            .namespace = get_env_var!("POD_NAMESPACE")
            .pod = get_env_var!("POD_NAME")
            .cluster_id = get_env_var!("CLUSTER_ID")
            .service_name = get_env_var!("SERVICE_NAME")
            .cluster_env = get_env_var!("CLUSTER_ENV")

      sinks:
        logs:
          type: loki
          inputs: [enrich]
          endpoint: "{{ required "vectorRemote.logsEndpoint is required when vectorRemote is enabled" $v.logsEndpoint }}"
          healthcheck:
            enabled: false
          {{- if $v.auth.secretName }}
          auth:
            strategy: basic
            user: "{{ "$" }}{{ "{MONITORING_USERNAME}" }}"
            password: "{{ "$" }}{{ "{MONITORING_PASSWORD}" }}"
          {{- end }}
          encoding:
            codec: text
          labels:
            app: "{{ "{{ app }}" }}"
            job: "{{ "{{ job }}" }}"
            role: "{{ "{{ role }}" }}"
            namespace: "{{ "{{ namespace }}" }}"
            pod: "{{ "{{ pod }}" }}"
            level: "{{ "{{ level }}" }}"
            cluster_id: "{{ "{{ cluster_id }}" }}"
            service_name: "{{ "{{ service_name }}" }}"
            cluster_env: "{{ "{{ cluster_env }}" }}"
          remove_label_fields: true
      VECEOF
      mkdir -p /tmp/vector-data
      exec vector -c /tmp/vector.yaml
  env:
    - name: POD_NAME
      valueFrom:
        fieldRef:
          fieldPath: metadata.name
    - name: POD_NAMESPACE
      valueFrom:
        fieldRef:
          fieldPath: metadata.namespace
    {{- if $v.auth.secretName }}
    - name: MONITORING_USERNAME
      valueFrom:
        secretKeyRef:
          name: {{ $v.auth.secretName }}
          key: {{ $v.auth.usernameKey }}
    - name: MONITORING_PASSWORD
      valueFrom:
        secretKeyRef:
          name: {{ $v.auth.secretName }}
          key: {{ $v.auth.passwordKey }}
    {{- end }}
    - name: ROLE
      value: {{ .role | quote }}
    - name: CLUSTER_ID
      value: {{ $v.extraLabels.cluster_id | default "" | quote }}
    - name: SERVICE_NAME
      value: {{ $v.extraLabels.service_name | default "" | quote }}
    - name: CLUSTER_ENV
      value: {{ $v.extraLabels.cluster_env | default "" | quote }}
  {{- with $v.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end }}
